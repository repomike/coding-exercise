import * as React from 'react';

export function App() {
  return <h1>Hello, World!</h1>;
}