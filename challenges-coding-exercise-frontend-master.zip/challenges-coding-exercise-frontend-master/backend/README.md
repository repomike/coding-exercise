# GraphQL Pokemon Server

## Run

```
$ npm install
$ npm start
```